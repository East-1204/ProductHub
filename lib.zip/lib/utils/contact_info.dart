const String defaultSupplierPhone = '+628123456789';
const String defaultSupplierEmail = 'supplier@example.com';
const String defaultSupplierWhatsApp = '628123456789'; // use international number without '+' for wa.me
